def do_something():
    print("Hello World!")
