
#!/Users/szymon/anaconda/envs/python36/bin/python

from distutils.core import setup

setup(name='MyPiPy',
      version='0.1dev',
      description='First dev verson',
      author='Szymon Prajs',
      author_email='S.Prajs@soton.ac.uk',
      packages=['MyPiPy'],
     ) 